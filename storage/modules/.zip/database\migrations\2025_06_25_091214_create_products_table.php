<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('products', function (Blueprint $table) {
$table->id();
            $table->integer('category_id')->nullable();
            $table->text('description')->nullable();
            $table->boolean('enabled')->default(true);
            $table->string('name', 255);
            $table->decimal('price');
            $table->string('sku', 100)->nullable()->unique();
            $table->string('slug', 255)->unique();
            $table->timestamps();
            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('products');
    }
};