<?php

use Illuminate\Support\Facades\Route;
use Modules\ShopModule\app\Http\Controllers\Api\ProductController;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your module. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group.
|
*/

Route::middleware(['api'])->prefix('api/shop-module')->group(function () {
    Route::apiResource('products', ProductController::class);
});
