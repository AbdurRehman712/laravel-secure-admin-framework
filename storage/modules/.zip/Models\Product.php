<?php

namespace Modules\ShopModule\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Product extends Model
{
    use SoftDeletes;

    protected $table = 'products';

    protected $fillable = [
        'category_id',
        'description',
        'enabled',
        'name',
        'price',
        'sku',
        'slug'
    
    ];

    protected $casts = [
        'category_id' => 'integer',
        'enabled' => 'boolean',
        'price' => 'decimal:2',
        'deleted_at' => 'datetime'
    ];

    
}
